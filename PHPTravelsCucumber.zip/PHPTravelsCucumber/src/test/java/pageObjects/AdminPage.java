package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AdminPage {
	
    WebDriver driver;
	
	@FindBy(xpath="(//input[@name='email'])[1]")
	private WebElement Email;
	
	@FindBy(xpath="(//input[@name='password'])[1]")
	private WebElement Password;
	
	@FindBy(xpath="//span[text()='Login']")
	private WebElement Login;
	
	@FindBy(xpath="(//a[text()='Bookings'])[1]")
	private WebElement Bookings;
	
	@FindBy(xpath="//div[text()='Cancelled Bookings']")
	private WebElement CanBookings;
	
	@FindBy(xpath="//div[text()='Pending Bookings']")
	private WebElement PenBookings;
	
	@FindBy(xpath="//div[text()='Pending Bookings']//preceding-sibling::div")
	private WebElement PenBookCount;
	
	@FindBy(xpath="//option[text()='pending']//parent::select")
	private WebElement BookingStatus;
	
	@FindBy(xpath="//option[text()='Confirmed']")
	private WebElement Confirm;
	
	@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[2]/div/div/div[2]/div/table/tbody/tr/td[15]/button")
	private WebElement Delete;
	
	@FindBy(xpath="//div[text()='Paid Bookings']")
	private WebElement PaidBookings;
	
	@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[2]/div/div/div[2]/div/table/tbody/tr[1]/td[14]/a")
	private WebElement Invoice;
	
	@FindBy(xpath="//strong[text()='Reservation Number:']")
	private WebElement ReservationNumber;
	
	@FindBy(xpath="//a[text()='Website']")
	private WebElement Website;
	
	@FindBy(xpath="(//i[text()='person'])[1]")
	private WebElement Profile;
	
	@FindBy(xpath="//div[text()='Logout']")
	private WebElement LogOut;
	
	public AdminPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	public void setEmail(String email)
	{
		Email.sendKeys(email);
	}
	
	public void setPassword(String password)
	{
		Password.sendKeys(password);	
	}
	
	public void ClickLogin()
	{
		Login.click();	
	}
	
	public void ClickBookings()
	{
		Bookings.click();	
	}
	
	public void ClickCanBookings()
	{
		CanBookings.click();	
	}
	
	public void ClickPenBookings()
	{
		PenBookings.click();	
	}
	
	public String getTextofCount()
	{
	    return PenBookCount.getText();			
	}
	
	public void ClickBookSts()
	{
		BookingStatus.click();	
	}
	
	public void ClickConfirm()
	{
		Confirm.click();	
	}
	
	public void ClickDelete()
	{
		Delete.click();	
	}
	
	public void ClickPaidBookings()
	{
		PaidBookings.click();	
	}
	
	public void ClickInvoice()
	{
		Invoice.click();	
	}
	
	public String ResNo() throws InterruptedException
	{
		String ResNo=ReservationNumber.getText();
		Thread.sleep(3000);
		return ResNo;
	}
	
	public void ClickWebsite()
	{
		Website.click();
	}
	
	public void ClickProfile()
	{
		Profile.click();
	}
	
	public void ClickLogOut()
	{
		LogOut.click();
	}
	
	public boolean ButtonEnable()
	{
		return Login.isEnabled();
	}

}
