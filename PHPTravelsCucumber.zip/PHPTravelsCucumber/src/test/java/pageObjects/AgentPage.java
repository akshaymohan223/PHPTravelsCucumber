package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AgentPage {
	
WebDriver driver;

@FindBy(xpath="//button[text()='Got It']")
private WebElement AcceptCookies;
	
@FindBy(xpath="//input[@placeholder='Email']")
private WebElement Email;

@FindBy(xpath="//input[@placeholder='Password']")
private WebElement Password;

@FindBy(xpath="(//button[@type='submit'])[1]")
private WebElement Login;

@FindBy(xpath="//button[@id='currency']")
private WebElement Currency;

@FindBy(xpath="//a[text()=' INR']")
private WebElement INR;

@FindBy(xpath="(//a[text()=' My Bookings'])[2]")
private WebElement MyBookings;

@FindBy(xpath="(//a[text()=' Add Funds'])[2]")
private WebElement AddFunds;

@FindBy(xpath="(//a[text()=' My Profile'])[2]")
private WebElement MyProfile;

@FindBy(xpath="(//img[@alt='logo'])[1]")
private WebElement Home;

@FindBy(xpath="//a[text()='Hotels']")
private WebElement Hotel;

@FindBy(xpath="//span[text()=' Search by City']")
private WebElement CityName;

@FindBy(xpath="//input[@type='search']")
private WebElement CityInput;

@FindBy(xpath="//i[@class='flag in']//parent::li")
private WebElement Option;

@FindBy(xpath="//button[@id='submit']")
private WebElement HotelSearch;

@FindBy(xpath="//strong[text()='Back To Search']")
private WebElement BacktoSearch;

@FindBy(xpath="//a[text()='flights']")
private WebElement Flights;

@FindBy(xpath="//a[text()='Tours']")
private WebElement Tours;

@FindBy(xpath="//a[text()='visa']")
private WebElement Visa;

@FindBy(xpath="//a[text()='Blog']")
private WebElement Blog;

@FindBy(xpath="//a[text()='Offers']")
private WebElement Offers;

@FindBy(xpath="(//button[@id='currency'])[2]")
private WebElement Account;

@FindBy(xpath="(//a[text()=' Logout'])[1]")
private WebElement LogOut;
	
	public AgentPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	public void ClickAcceptCookies()
	{
		AcceptCookies.click();	
	}
	
	public void setEmail(String email)
	{
		Email.sendKeys(email);
	}
	
	public void setPassword(String password)
	{
		Password.sendKeys(password);	
	}
	
	public void ClickLogin()
	{
		Login.click();	
	}
	
	public void ClickCurrency()
	{
		Currency.click();	
	}
	
	public void ClickINR()
	{
		INR.click();	
	}
	
	public void ClickMyBookings()
	{
		MyBookings.click();	
	}
	
	public void ClickAddFunds()
	{
		AddFunds.click();	
	}
	
	public void ClickMyProfile()
	{
		MyProfile.click();	
	}
	
	public void ClickHome()
	{
		Home.click();	
	}
	
	public void ClickHotel()
	{
		Hotel.click();	
	}
	
	public void ClickCityName()
	{
		CityName.click();	
	}
	
	public void setCityInput(String city)
	{
		CityInput.sendKeys(city);
	}
	
	public void ClickOption()
	{
		Option.click();	
	}
	
	public void ClickHotelSearch()
	{
		HotelSearch.click();	
	}
	
	public String BckSr() throws InterruptedException
	{
		String BckSr=BacktoSearch.getText();
		Thread.sleep(3000);
		return BckSr;
	}
	
	public void ClickFlights()
	{
		Flights.click();	
	}
	
	public void ClickTours()
	{
		Tours.click();	
	}
	
	public void ClickVisa()
	{
		Visa.click();	
	}
	
	public void ClickBlog()
	{
		Blog.click();	
	}
	
	public void ClickOffers()
	{
		Offers.click();	
	}
	
	public void ClickAccount()
	{
		Account.click();
	}
	
	public void ClickLogOut()
	{
		LogOut.click();
	}
	
	public boolean ButtonEnable()
	{
		return Login.isEnabled();
	}

}
