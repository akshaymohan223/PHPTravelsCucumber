package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CustomerPage {
	
	WebDriver driver;
	
	@FindBy(xpath="//button[text()='Got It']")
	private WebElement AcceptCookies;
	
	@FindBy(xpath="//input[@placeholder='Email']")
	private WebElement Email;
	
	@FindBy(xpath="//input[@placeholder='Password']")
	private WebElement Password;
	
	@FindBy(xpath="(//button[@type='submit'])[1]")
	private WebElement Login;
	
	@FindBy(xpath="(//a[text()=' My Bookings'])[2]")
	private WebElement MyBookings;
	
	@FindBy(xpath="//a[text()=' View Voucher']")
	private WebElement ViewVoucher;
	
	@FindBy(xpath="//strong[text()='Reservation Number:']")
	private WebElement ReservationNumber;
	
	@FindBy(xpath="(//a[text()=' Add Funds'])[2]")
	private WebElement AddFunds;
	
	@FindBy(xpath="//input[@value='paypal']")
	private WebElement PWPbutton;
	
	@FindBy(xpath="//input[@value='50']")
	private WebElement Amount;
	
	@FindBy(xpath="//button[text()='Pay Now ']")
	private WebElement PayNow;
	
	@FindBy(xpath="//div[@tabindex=0]")
	private WebElement PayPal;
	
	@FindBy(xpath="(//a[text()=' My Profile'])[2]")
	private WebElement MyProfile;
	
	@FindBy(xpath="//input[@name='address1']")
	private WebElement Address;
	
	@FindBy(xpath="//input[@name='address2']")
	private WebElement Address2;
	
	@FindBy(xpath="/html/body/section[1]/div/div[2]/div/div[1]/div/div/div[2]/form/div[3]/button")
	private WebElement UpdateProfile;
	
	@FindBy(xpath="(//button[@id='currency'])[2]")
	private WebElement Account;
	
	@FindBy(xpath="(//a[text()=' Logout'])[1]")
	private WebElement LogOut;
	
	
	
	public CustomerPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	public void ClickAcceptCookies()
	{
		AcceptCookies.click();	
	}
	
	public void setEmail(String email)
	{
		Email.sendKeys(email);
	}
	
	public void setPassword(String password)
	{
		Password.sendKeys(password);	
	}
	
	public void ClickLogin()
	{
		Login.click();	
	}
	
	public void ClickAccount()
	{
		Account.click();
	}
	
	public void ClickMyBookings()
	{
		MyBookings.click();
	}
	
	public void ClickViewVoucher()
	{
		ViewVoucher.click();
	}
	
	public String ResNo() throws InterruptedException
	{
		String ResNo=ReservationNumber.getText();
		Thread.sleep(3000);
		return ResNo;
	}
	
	public void ClickAddFunds()
	{
		AddFunds.click();
	}
	
	public void ClickPWPbutton()
	{
		PWPbutton.click();
	}
	
	public void ClickAmount()
	{
		Amount.click();
	}
	
	public void ClickPayNow()
	{
		PayNow.click();
	}
	
	public void ClickPayPal()
	{
		PayPal.click();
	}
	
	public void ClickMyProfile()
	{
		MyProfile.click();
	}
	
	public void setAddress(String address)
	{
		Address.clear();
		Address.sendKeys(address);	
	}
	
	public void setAddress2(String address2)
	{
		Address2.clear();
		Address2.sendKeys(address2);	
	}
	
	public void ClickUpdateProfile()
	{
		UpdateProfile.click();
	}
	
	public void ClickLogOut()
	{
		LogOut.click();
	}
	
	public boolean ButtonEnable()
	{
		return Login.isEnabled();
	}
	
	
	

}
