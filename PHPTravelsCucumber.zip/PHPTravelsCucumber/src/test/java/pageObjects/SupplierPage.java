package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SupplierPage {
	
    WebDriver driver;
	
	@FindBy(xpath="(//input[@name='email'])[1]")
	private WebElement Email;
	
	@FindBy(xpath="(//input[@name='password'])[1]")
	private WebElement Password;
	
	@FindBy(xpath="//span[text()='Login']")
	private WebElement Login;
	
	@FindBy(xpath="//div[text()='Sales overview & summary']")
	private WebElement SalesSummary;
	
	@FindBy(xpath="//h2[text()='Revenue Breakdown 2023']")
	private WebElement RevenueBreakdown;
	
	@FindBy(xpath="//a[text()='Bookings']")
	private WebElement Bookings;
	
	@FindBy(xpath="(//i[text()='luggage']//parent::div)//parent::a")
	private WebElement Tours;
	
	@FindBy(xpath="(//i[text()='person'])[1]")
	private WebElement Profile;
	
	@FindBy(xpath="//div[text()='Logout']")
	private WebElement LogOut;
	
	public SupplierPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	public void setEmail(String email)
	{
		Email.sendKeys(email);
	}
	
	public void setPassword(String password)
	{
		Password.sendKeys(password);	
	}
	
	public void ClickLogin()
	{
		Login.click();	
	}
	
	public String SaleSum() throws InterruptedException
	{
		String SaleSum=SalesSummary.getText();
		Thread.sleep(3000);
		return SaleSum;
	}
	
	public String RevBrk() throws InterruptedException
	{
		String RevBrk=RevenueBreakdown.getText();
		Thread.sleep(3000);
		return RevBrk;
	}
	
	public void ClickBookings()
	{
		Bookings.click();
	}
	
	public void ClickTours()
	{
		Tours.click();
	}
	
	public void ClickProfile()
	{
		Profile.click();
	}
	
	public void ClickLogOut()
	{
		LogOut.click();
	}
	
	public boolean ButtonEnable()
	{
		return Tours.isEnabled();
	}

}
