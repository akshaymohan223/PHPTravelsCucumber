package stepDefenitions;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;
import pageObjects.AgentPage;

public class AgentSteps {
	
	public WebDriver driver;
	public AgentPage gp;
	
	@SuppressWarnings("deprecation")
	@Given("Agent launch Chrome browser")
	public void agent_launch_chrome_browser() {
		driver=new ChromeDriver();
	    gp=new AgentPage (driver);
	    
	    driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	    driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
	    driver.manage().window().maximize();
	}

	@When("Agent opens URL {string}")
	public void agent_opens_url(String url) throws InterruptedException {
		driver.get(url);
	    Thread.sleep(2000);
	    gp.ClickAcceptCookies();
	    Thread.sleep(2000);
	}

	@When("Agent enters Email as {string} and Password as {string}")
	public void agent_enters_email_as_and_password_as(String email, String password) throws InterruptedException {
		gp.setEmail(email);
	    gp.setPassword(password);
	    Thread.sleep(2000);
	}

	@When("Agent Click on Login")
	public void agent_click_on_login() throws InterruptedException {
		gp.ClickLogin();
	    Thread.sleep(2000);
	}

	@Then("Agent Page Title should be {string}")
	public void agent_page_title_should_be(String title) throws InterruptedException {
		Assert.assertEquals(title, driver.getTitle());
		Thread.sleep(2000);
	}
	
	@Then("Agent click on Currency button")
	public void agent_click_on_currency_button() throws InterruptedException {
	    gp.ClickCurrency();
	    Thread.sleep(2000);
	}

	@Then("Agent update currency to INR")
	public void agent_update_currency_to_inr() throws InterruptedException {
	    gp.ClickINR();
	    Thread.sleep(2000);
	}

	@Then("currency should be displayed as INR")
	public void currency_should_be_displayed_as_inr() {
		String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/";
	    Assert.assertEquals(expected, actual);
	}
	
	@Then("Agent Click on My Bookings button")
	public void agent_click_on_my_bookings_button() throws InterruptedException {
		gp.ClickMyBookings();
		Thread.sleep(5000);
	    String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/account/bookings";
	    Assert.assertEquals(expected, actual);
	}

	@Then("Agent Click on Add Funds button")
	public void agent_click_on_add_funds_button() throws InterruptedException {
		gp.ClickAddFunds();
	    Thread.sleep(5000);
	    String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/account/add_funds";
	    Assert.assertEquals(expected, actual);
	}

	@Then("Agent Click on My Profile button")
	public void agent_click_on_my_profile_button() throws InterruptedException {
		gp.ClickMyProfile();
	    Thread.sleep(5000);
	    String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/account/profile";
	    Assert.assertEquals(expected, actual);
	}

	@Then("Agent Click on Home button")
	public void agent_click_on_home_button() throws InterruptedException {
		gp.ClickHome();
	    Thread.sleep(5000);
	    String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/";
	    Assert.assertEquals(expected, actual);
	}

	@Then("Agent Click on Hotel button")
	public void agent_click_on_hotel_button() throws InterruptedException {
		gp.ClickHotel();
	    Thread.sleep(5000);
	    String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/hotels";
	    Assert.assertEquals(expected, actual);
	}
	
	@Then("Agent enters city name as {string}")
	public void agent_enters_city_name_as(String city) throws InterruptedException {
	    gp.ClickCityName();
	    Thread.sleep(2000);
	    gp.setCityInput(city);
	    Thread.sleep(2000);
	    gp.ClickOption();
	    Thread.sleep(2000);
	}

	@Then("Agent click on Search Hotel button")
	public void agent_click_on_search_hotel_button() throws InterruptedException {
	    gp.ClickHotelSearch();
	    Thread.sleep(2000);
	}

	@Then("Hotel details should be displayed")
	public void hotel_details_should_be_displayed() throws InterruptedException {
		String actual=gp.BckSr();
	    String expected="Back To Search";
	    Assert.assertEquals(expected, actual);
	    driver.close();
	    Thread.sleep(2000);
	}

	@Then("Agent Click on Flights button")
	public void agent_click_on_flights_button() throws InterruptedException {
		gp.ClickFlights();
	    Thread.sleep(5000);
	    String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/flights";
	    Assert.assertEquals(expected, actual);
	}

	@Then("Agent Click on Tours button")
	public void agent_click_on_tours_button() throws InterruptedException {
		gp.ClickTours();
	    Thread.sleep(5000);
	    String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/tours";
	    Assert.assertEquals(expected, actual);
	}

	@Then("Agent Click on Visa button")
	public void agent_click_on_visa_button() throws InterruptedException {
		gp.ClickVisa();
	    Thread.sleep(5000);
	    String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/visa";
	    Assert.assertEquals(expected, actual);
	}

	@Then("Agent Click on Blog button")
	public void agent_click_on_blog_button() throws InterruptedException {
		gp.ClickBlog();
	    Thread.sleep(5000);
	    String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/blog";
	    Assert.assertEquals(expected, actual);
	}

	@Then("Agent Click on Offers button")
	public void agent_click_on_offers_button() throws InterruptedException {
		gp.ClickOffers();
	    Thread.sleep(5000);
	    String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/offers";
	    Assert.assertEquals(expected, actual);
	}
	
	@Then("Agent Click on Account button")
	public void agent_click_on_account_button() throws InterruptedException {
		gp.ClickAccount();
	    Thread.sleep(2000);
	}

	@Then("Agent click on Logout button")
	public void agent_click_on_logout_button() throws InterruptedException {
		gp.ClickLogOut();
	    Thread.sleep(2000);
	}

	@Then("Agent Close browser")
	public void agent_close_browser() throws InterruptedException {
		driver.quit();
	    Thread.sleep(2000);
	}

	@Then("Agent page should display wrong credentials")
	public void agent_page_should_display_wrong_credentials() {
		String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/login/failed";
	    Assert.assertEquals(expected, actual);
	}

	@Then("Agent page should display Please fill out this field")
	public void agent_page_should_display_please_fill_out_this_field() {
		String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/login";
	    Assert.assertEquals(expected, actual);
	}

}
