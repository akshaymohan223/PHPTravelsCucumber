package stepDefenitions;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;
import io.cucumber.java.en.When;
import pageObjects.SupplierPage;

public class SupplierSteps {
	
	public WebDriver driver;
	public SupplierPage sp;
	
	@SuppressWarnings("deprecation")
	@Given("Supplier launch Chrome browser")
	public void supplier_launch_chrome_browser() {
		driver=new ChromeDriver();
	    sp=new SupplierPage (driver);
	    
	    driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	    driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
	    driver.manage().window().maximize();  
	}

	@When("Supplier opens URL {string}")
	public void supplier_opens_url(String url) throws InterruptedException {
		driver.get(url);
	    Thread.sleep(2000);
	}

	@When("Supplier enters Email as {string} and Password as {string}")
	public void supplier_enters_email_as_and_password_as(String email, String password) throws InterruptedException {
		sp.setEmail(email);
		Thread.sleep(2000);
	    sp.setPassword(password);
	    Thread.sleep(2000);
	}

	@When("Supplier Click on Login")
	public void supplier_click_on_login() throws InterruptedException {
		sp.ClickLogin();
	    Thread.sleep(2000);
	}

	@Then("Supplier Page Title should be {string}")
	public void supplier_page_title_should_be(String title) throws InterruptedException {
		Assert.assertEquals(title, driver.getTitle());
		Thread.sleep(2000);
	}
	
	@Then("Supplier Page should contain the text Sales and overview summary")
	public void supplier_page_should_contain_the_text_sales_and_overview_summary() throws InterruptedException {
		String actual=sp.SaleSum();
	    String expected="Sales overview & summary";
	    Assert.assertEquals(expected, actual);
	    driver.close();
	    Thread.sleep(2000);
	}
	
	@Then("Supplier Page should display the Revenue Breakdown")
	public void supplier_page_should_display_the_revenue_breakdown() throws InterruptedException {
		String actual=sp.RevBrk();
	    String expected="Revenue Breakdown 2023";
	    Assert.assertEquals(expected, actual);
	    driver.close();
	    Thread.sleep(2000);
	}
	
	@Then("Supplier click on Tours button")
	public void supplier_click_on_tours_button() throws InterruptedException {
	    sp.ClickTours();
	    if(sp.ButtonEnable())
	    {
	    	Assert.assertTrue(true);
	    }
	    else
	    {
	    	Assert.assertTrue(false);
	    }
	    Thread.sleep(2000);
	}
	
	@Then("Supplier click on Bookings button")
	public void supplier_click_on_bookings_button() throws InterruptedException {
	    sp.ClickBookings();
	    Thread.sleep(2000);
	}

	@Then("Supplier Page should display booking status")
	public void supplier_page_should_display_booking_status() {
		 String actual=driver.getCurrentUrl();
		 String expected="https://phptravels.net/api/supplier/bookings";
		 Assert.assertEquals(expected, actual);
	}

	@Then("Supplier Click on Profile button")
	public void supplier_click_on_profile_button() throws InterruptedException {
		sp.ClickProfile();
		Thread.sleep(2000);
	}

	@Then("Supplier click on Logout button")
	public void supplier_click_on_logout_button() throws InterruptedException {
		sp.ClickLogOut();
	    Thread.sleep(2000);
	}

	@Then("Supplier Close browser")
	public void supplier_close_browser() throws InterruptedException {
		driver.quit();
	    Thread.sleep(2000);
	}

	@Then("Supplier Page should display Invalid login credentials")
	public void supplier_page_should_display_invalid_login_credentials() {
		String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/api/supplier";
	    Assert.assertEquals(expected, actual);
	}

	@Then("Supplier Page should display Email and Password fields are required")
	public void supplier_page_should_display_email_and_password_fields_are_required() {
		String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/api/supplier";
	    Assert.assertEquals(expected, actual);
	}

}
