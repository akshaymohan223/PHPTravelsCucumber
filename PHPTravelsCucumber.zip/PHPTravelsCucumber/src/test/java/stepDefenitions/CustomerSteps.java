package stepDefenitions;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;
import pageObjects.CustomerPage;

public class CustomerSteps {
	
	public WebDriver driver;
	public CustomerPage cp;
	
	@SuppressWarnings("deprecation")
	@Given("Customer launch Chrome browser")
	public void customer_launch_chrome_browser() {
	    driver=new ChromeDriver();
	    cp=new CustomerPage (driver);
	    
	    driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	    driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
	    driver.manage().window().maximize();
	    
	}

	@When("Customer opens URL {string}")
	public void customer_opens_url(String url) throws InterruptedException {
	    driver.get(url);
	    Thread.sleep(2000);
	    cp.ClickAcceptCookies();
	    Thread.sleep(2000);
	}

	@When("Customer enters Email as {string} and Password as {string}")
	public void customer_enters_email_as_and_password_as(String email, String password) throws InterruptedException {
	    cp.setEmail(email);
	    cp.setPassword(password);
	    Thread.sleep(2000);
	    }

	@When("Customer Click on Login")
	public void customer_click_on_login() throws InterruptedException {
	    cp.ClickLogin();
	    Thread.sleep(2000);
	}
	
	@Then("Customer Page Title should be {string}")
	public void customer_page_title_should_be(String title) throws InterruptedException {
		Assert.assertEquals(title, driver.getTitle());
		Thread.sleep(2000);
	}
	
	@Then("Customer Click on My Bookings button")
	public void customer_click_on_my_bookings_button() throws InterruptedException {
	    cp.ClickMyBookings();
	    Thread.sleep(5000);
	    String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/account/bookings";
	    Assert.assertEquals(expected, actual);
	    }
	
	@Then("Customer Click on View Voucher")
	public void customer_click_on_view_voucher() throws InterruptedException {
	    cp.ClickViewVoucher();
	    Thread.sleep(5000);
	    ArrayList<String> tabs=new ArrayList<String>(driver.getWindowHandles()); 
		driver.switchTo().window(tabs.get(1));
		driver.getCurrentUrl();
	}
	
	@Then("Voucher should be displayed")
	public void voucher_should_be_displayed() throws InterruptedException {
		String actual=cp.ResNo();
	    String expected="Reservation Number:";
	    Assert.assertEquals(expected, actual);
	    driver.close();
	    Thread.sleep(2000);
	}
	
	@Then("Customer Click on Add Funds button")
	public void customer_click_on_add_funds_button() throws InterruptedException {
	    cp.ClickAddFunds();
	    Thread.sleep(5000);
	    String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/account/add_funds";
	    Assert.assertEquals(expected, actual);
	}
	
	@Then("Customer Click on Pay with PayPal button")
	public void customer_click_on_pay_with_pay_pal_button() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, 4000)");
		Thread.sleep(2000);
		cp.ClickPWPbutton();
	    Thread.sleep(2000);
	}
	
	@Then("Customer Click on amount")
	public void customer_click_on_amount() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, -4000)");
		cp.ClickAmount();
	    Thread.sleep(2000);
	}

	@Then("Customer Click on Pay Now button")
	public void customer_click_on_pay_now_button() throws InterruptedException {
	    cp.ClickPayNow();
	    Thread.sleep(2000);
	}
	
	@Then("Page should display pay with PayPal")
	public void page_should_display_pay_with_pay_pal() {
		 String actual=driver.getCurrentUrl();
		    String expected="https://phptravels.net/payment/paypal";
		    Assert.assertEquals(expected, actual);
	}
	
	@Then("Customer Click on My Profile button")
	public void customer_click_on_my_profile_button() throws InterruptedException {
	    cp.ClickMyProfile();
	    Thread.sleep(5000);
	    String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/account/profile";
	    Assert.assertEquals(expected, actual);
	}
	
	@Then("Customer enters the address as {string} and address2 as {string}")
	public void customer_enters_the_address_as_and_address2_as(String address, String address2) throws InterruptedException {
	   cp.setAddress(address);
	   cp.setAddress2(address2);
	   JavascriptExecutor js = (JavascriptExecutor) driver;
	   js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
	   Thread.sleep(2000);
	}
	
	@Then("Customer Click on Update Profile button")
	public void customer_click_on_update_profile_button() throws InterruptedException {
	    cp.ClickUpdateProfile();
	    Thread.sleep(2000);
	}
	
	@Then("address and address2 should be changed")
	public void address_and_address2_should_be_changed() {
		String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/account/profile/success";
	    Assert.assertEquals(expected, actual);
	}

	@Then("Customer Click on Account button")
	public void customer_click_on_account_button() throws InterruptedException {
	    cp.ClickAccount();
	    Thread.sleep(2000);
	}
	
	@Then("Customer click on Logout button")
	public void customer_click_on_logout_button() throws InterruptedException {
	    cp.ClickLogOut();
	    Thread.sleep(2000);
	}
	
	@Then("Customer Close browser")
	public void customer_close_browser() throws InterruptedException {
	    driver.quit();
	    Thread.sleep(2000);
	}
	
	@Then("page should display wrong credentials")
	public void page_should_display_wrong_credentials() {
	    String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/login/failed";
	    Assert.assertEquals(expected, actual);
	    
	}
	
	@Then("page should display Please fill out this field")
	public void page_should_display_please_fill_out_this_field() {
		String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/login";
	    Assert.assertEquals(expected, actual);
	}
	
}
