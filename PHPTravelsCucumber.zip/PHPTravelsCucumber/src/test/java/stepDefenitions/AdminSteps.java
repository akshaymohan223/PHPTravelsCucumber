package stepDefenitions;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;
import pageObjects.AdminPage;

public class AdminSteps {
	
	public WebDriver driver;
	public AdminPage ap;
	
	@SuppressWarnings("deprecation")
	@Given("Admin launch Chrome browser")
	public void admin_launch_chrome_browser() {
		driver=new ChromeDriver();
	    ap=new AdminPage (driver);
	    
	    driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	    driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
	    driver.manage().window().maximize();
	}

	@When("Admin opens URL {string}")
	public void admin_opens_url(String url) throws InterruptedException {
		driver.get(url);
	    Thread.sleep(2000);
	}

	@When("Admin enters Email as {string} and Password as {string}")
	public void admin_enters_email_as_and_password_as(String email, String password) throws InterruptedException {
		ap.setEmail(email);
	    ap.setPassword(password);
	    Thread.sleep(2000);
	}

	@When("Admin Click on Login")
	public void admin_click_on_login() throws InterruptedException {
		ap.ClickLogin();
	    Thread.sleep(2000);
	}

	@Then("Admin Page Title should be {string}")
	public void admin_page_title_should_be(String title) throws InterruptedException {
		Assert.assertEquals(title, driver.getTitle());
		Thread.sleep(2000);
	}
	
	@Then("Admin click on Bookings button")
	public void admin_click_on_bookings_button() throws InterruptedException {
	    ap.ClickBookings();
	    Thread.sleep(2000);
	}
	
	@Then("Admin click on Pending Bookings button")
	public void admin_click_on_pending_bookings_button() throws InterruptedException {
	    ap.ClickPenBookings();
	    Thread.sleep(2000);
	    String PendingBookingCount1=ap.getTextofCount();
	    System.out.println("Count before changing status= "+PendingBookingCount1);
	    Thread.sleep(2000);
	    String count=ap.getTextofCount();
	    int value=Integer.parseInt(count);
	    System.out.println("Total Pending Bookings= "+value);
	}

	@Then("Admin change booking status from Pending to Confirmed")
	public void admin_change_booking_status_from_pending_to_confirmed() throws InterruptedException {
	    ap.ClickBookSts();
	    Thread.sleep(2000);
	    ap.ClickConfirm();
	    Thread.sleep(2000);
	}

	@Then("Admin verify the count in Dashboard")
	public void admin_verify_the_count_in_dashboard() {
		String PendingBookingCount2=ap.getTextofCount();
	    System.out.println("Count after changing status= "+PendingBookingCount2);
	}
	
	@Then("Admin click on Cancelled Bookings button")
	public void admin_click_on_cancelled_bookings_button() throws InterruptedException {
	    ap.ClickCanBookings();
	    Thread.sleep(2000);
	}

	@Then("Admin click on Delete Record button")
	public void admin_click_on_delete_record_button() throws InterruptedException {
	    ap.ClickDelete();
	    Thread.sleep(2000);
	}

	@Then("Record should be deleted")
	public void record_should_be_deleted() {
	    Alert alert=driver.switchTo().alert();
	    String alertMessage=alert.getText();
	    String expectedMessage="Are you sure to delete?";
	    Assert.assertEquals(expectedMessage, alertMessage);
	    alert.accept();
	}

	@Then("Admin click on Paid Bookings button")
	public void admin_click_on_paid_bookings_button() throws InterruptedException {
	    ap.ClickPaidBookings();
	    Thread.sleep(2000);
	}

	@Then("Admin click on Invoice button")
	public void admin_click_on_invoice_button() throws InterruptedException {
	    ap.ClickInvoice();
	    Thread.sleep(2000);
	    ArrayList<String> tabs=new ArrayList<String>(driver.getWindowHandles()); 
		driver.switchTo().window(tabs.get(1));
		driver.getCurrentUrl();
	}

	@Then("Booking Invoice should be displayed")
	public void booking_invoice_should_be_displayed() throws InterruptedException {
		String actual=ap.ResNo();
	    String expected="Reservation Number:";
	    Assert.assertEquals(expected, actual);
	    driver.close();
	    Thread.sleep(2000);
	}
	
	@Then("Admin click on Website button")
	public void admin_click_on_website_button() throws InterruptedException {
	    ap.ClickWebsite();
	    Thread.sleep(15000);
	    ArrayList<String> tabs=new ArrayList<String>(driver.getWindowHandles()); 
		driver.switchTo().window(tabs.get(1));
		driver.getCurrentUrl();
	}

	@Then("Website should be opened")
	public void website_should_be_opened() throws InterruptedException {
		String actual=driver.getTitle();
		Thread.sleep(10000);
	    String expected="PHPTRAVELS | Travel Technology Partner - PHPTRAVELS";
	    Assert.assertEquals(expected, actual);
	    Thread.sleep(2000);
	}

	@Then("Admin Click on Profile button")
	public void admin_click_on_profile_button() throws InterruptedException {
	   ap.ClickProfile();
	   Thread.sleep(2000);
	}

	@Then("Admin click on Logout button")
	public void admin_click_on_logout_button() throws InterruptedException {
		ap.ClickLogOut();
	    Thread.sleep(2000);
	}

	@Then("Admin Close browser")
	public void admin_close_browser() throws InterruptedException {
		driver.quit();
	    Thread.sleep(2000);
	}

	@Then("Admin page should display Enter valid login credentials")
	public void admin_page_should_display_enter_valid_login_credentials() {
		String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/api/admin";
	    Assert.assertEquals(expected, actual);
	}

	@Then("Admin page should display Email and Password fields are required")
	public void admin_page_should_display_email_and_password_fields_are_required() {
		String actual=driver.getCurrentUrl();
	    String expected="https://phptravels.net/api/admin";
	    Assert.assertEquals(expected, actual);
	}

}
